export * from "./footer-message";
