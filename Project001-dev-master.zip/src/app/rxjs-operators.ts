// import 'rxjs'; // adds ALL RxJS statics & operators to Observable

// See node_module/rxjs/Rxjs.js
// Import just the rxjs statics and operators we need for THIS app.

// tslint:disable:no-import-side-effect

// Statics
// import 'rxjs/add/observable/throw';

// // Operators
// import 'rxjs/add/operator/catch';
// import 'rxjs/add/operator/debounceTime';
// import 'rxjs/add/operator/distinctUntilChanged';
// import 'rxjs/add/operator/do';
// import 'rxjs/add/operator/map';
// import 'rxjs/add/operator/switchMap';
// import 'rxjs/add/operator/take';
// import 'rxjs/add/operator/timeout';
// import 'rxjs/add/operator/toPromise';

// tslint:enable:no-import-side-effect
