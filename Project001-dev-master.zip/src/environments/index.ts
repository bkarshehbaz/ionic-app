// Generated Mon Apr 28 2025 02:10:40 GMT+0500 (Pakistan Standard Time) by VVS webpack.config.js

export const ENV = {

	tk: "2quxuW-eJ2k3m-GAHCF4-e78ttc",
	tkM: "undefined",

	BASE_ENDPOINT: "https://vvsdo.api.vvsadmin.com",

	// getEnv: () => ENV.CURRENT_ENV || ENV.DEFAULT_ENV,
	// setEnv: (env) => ENV.CURRENT_ENV = env,
	CURRENT_ENV: "dev",
	// DEFAULT_ENV: "prod",
	ENVS: [
		"prod",
		"dev",
		"uat",
		"qa",
	],
	CURRENT_CHANNEL: "Master",
	CHANNELS: [
		"Production",
		"Master",
		"Qa",
		"Uat"
	],

	isIOS: false,
	isAndroid: false,

	IONIC_APP_ID: "f2d6a04b",

	buildTimestamp: "Mon Apr 28 2025 02:10:40 GMT+0500 (Pakistan Standard Time)",
	buildCommand: "/Users/macbookpro/.nvm/versions/node/v18.20.8/bin/node /Users/macbookpro/Downloads/Project001-dev-master/node_modules/.bin/ionic-app-scripts serve --webpack ./config/webpack.dev.config.js --port 4400",
	iosBuildVersion: "0.7.18",
	isNative: false,
	DEV_MODE_USERNAME: "gsano",
	DEV_MODE_PASSWORD: "791089875",
	VIN_API: "/DecodeVINValuesBatch/",
	environment: "dev",
	production: false,
	timeout: 4800,

	VVSPHOTOS_API: "https://vvsphotos.api.vvsadmin.com",
	// S3_HOST: "https://s3-us-west-2.amazonaws.com",
	// S3_BUCKET: "vvsphotos",

	ROLLBAR_ACCESS_TOKEN: "90b44744e3a14ab7a9980f2e75f91227",

	X_API_KEY: "my_public_key",

	MANATEE_IOS_KEY: "YF7Pw7S26L758dW/vVGQvfm/jKWNks1QDwbEYaCXaAE=",

	ENABLE_PROD_LOGGER: false,
	MINIFY_STORAGE_KEYS: false,
	ENABLE_DEBUG_MODE: true,

	GOOGLE_MAP_STATIC_API_BASE_URL: "/google_staticmap",
	GOOGLE_MAP_STATIC_API_KEY: "AIzaSyA6Kp0hqX1C_3F2oJewtr_zzi2_k8DB9iI",

	OPEN_ALPR_URL: "/openalpr",

	IONIC_ENV: "dev",
	CURR_ENV: "development",
	VVS_ENV: "dev",
	IONIC_SOURCE_MAP_TYPE: "eval-source-map",
	IONIC_GENERATE_SOURCE_MAP: "true",
	git: {
		short: "",
		tag: ""
	},
	ionicInfo: {}
};
