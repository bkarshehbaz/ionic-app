ionic run android --prod
