
export class CardNotesPhotosMapView {

}
